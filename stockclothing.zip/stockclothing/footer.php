   <!-- Footer site -->
   <footer class = "background_footer" style = "background-color:url(<?php the_field('background_footer') ?>)">
        <div class = "background_for_footer"><img src = "<?php the_field('background_for_footer') ?>"></div>
        <div class = "evromoda_footer"><?php the_field('evromoda_footer') ?></div>
        <div class = "menu_1">
        <ul>
        <?php 
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'items_wrap' => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
                'menu_class' => '',
                'menu_id' => '',
                'depth' => 1
            ));
            ?>
        </ul>
        </div>
        <div class = "sqr_1"></div>
        <div class = "sqr_2"></div>
        <div class = "sqr_3"></div>
        <div class = "sqr_4"></div>
        <div class = "sqr_5"></div>
        <a href = "<?php the_field('s_1') ?>"><div class = "insta"><img src = "<?php the_field('mes_1') ?>"></div></a>
        <a href = "<?php the_field('s_2') ?>"><div class = "twit"><img src = "<?php the_field('mes_2') ?>"></div></a>
        <a href = "<?php the_field('s_3') ?>"><div class = "vk"><img src = "<?php the_field('mes_3') ?>"></div></a>
        <div class="what_tele_footer"><?php the_field('what_tele_footer') ?></div>
        <div class = "number_footer"><?php the_field('number_footer') ?></div>
        <div class="site_footer"><?php the_field('site_footer') ?></div>
        <div class="www_evromoda_com_footer"><?php the_field('www_evromoda_com_footer') ?></div>
        <span class="sub"><?php the_field('sub') ?></span>
    </footer>
</body>
</html>
