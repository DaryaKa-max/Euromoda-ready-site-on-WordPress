<?
// правильный способ подключить стили и скрипты
add_action( 'wp_enqueue_scripts', 'stoevro_scripts' );
// add_action('wp_print_styles', 'theme_name_scripts'); // можно использовать этот хук он более поздний
function stoevro_scripts() {
    wp_enqueue_style( 'styleclothing', get_stylesheet_uri() );
    // Подключение файлов через ссылки
	wp_enqueue_script( 'script_jquery', 'https://code.jquery.com/jquery-3.5.1.min.js' );
	wp_enqueue_script( 'script_pooper', 'https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js' );
	wp_enqueue_script( 'script_bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js' );

	wp_enqueue_style( 'style_fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,700' );
	wp_enqueue_style( 'style_bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css' );
	wp_enqueue_style( 'style_font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );

}
add_action( 'after_setup_theme', 'theme_register_nav_menu' );
function theme_register_nav_menu() {
	register_nav_menu( 'primary', 'Primary Menu' );
}

function sizeimg(){
	add_theme_support('post-thumbnails');
}

    add_theme_support( 'html5', array( 'search-form' ) );


	function register_my_widgets(){
		register_sidebar( array(
			'name' => 'Wid-Header',
			'id' => 'homepage-sidebar',
			'description' => 'Выводиться как боковая панель только на главной странице сайта.',
			'before_widget' => '<li class="homepage-widget-block">',
			'after_widget' => '</li>',
			'before_title' => '<h2 class="widgettitle">',
			'after_title' => '</h2>',
		) );
	}
	add_action( 'widgets_init', 'register_my_widgets' );

	function true_search_form( $form ) {
		$form = '...'; // в эту переменную записываем новую поисковую форму
		return $form;
	}
	 
	add_filter( 'get_search_form', 'true_search_form' );