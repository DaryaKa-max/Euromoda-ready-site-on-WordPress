<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('description'); ?></title>
<?php wp_head(); ?>
</head>
<body>   
<div class = "background_body">
    <picture>
    <source srcset="http://works/wp-content/uploads/2022/03/760.png" media="(min-width:321px) and (max-width:760px)">
    <source srcset="http://works/wp-content/uploads/2022/03/320.png" media="(min-width:0px) and (max-width:320px)">

    <img src = "<?php the_field('background_body') ?>"/>

    </picture>
</div>
<!-- Header site -->
    <header>
        <div class="what_tele"><?php the_field('what_tele'); ?></div>
        <div class = "number"><?php the_field('number'); ?></div>
        <div class = "header_header"><?php the_field('header_header'); ?></div>
        <div class="site"><?php the_field('site'); ?></div>
        <div class="www_evromoda_com"><?php the_field('www_evromoda_com'); ?></div>

        <form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
            <input  id="searchsubmit" type = "image"  class = "input_pic" src = "<?php the_field('input_pic') ?>">
                <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-lupa.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/320-lupa.png" media="(min-width:0px) and (max-width:320px)">
                </picture>
            </input>
            <input type="text" value="" name="s" id="s" class = "input" >
        </form>

       <?php get_search_form( $echo = true ) ?>
    </header>




    

