    <!-- Content site -->
    <!-- Main slider -->
   <!-- Content details -->
   <div class = "pattern_content">
        <picture>
            <source srcset="http://works/wp-content/uploads/2022/03/760-uzor.png" media="(min-width:321px) and (max-width:760px)">
            <source srcset="http://works/wp-content/uploads/2022/03/320-uzor.png" media="(min-width:0px) and (max-width:320px)">

            <img srcset = "<?php the_field('pattern_content') ?>"/>

            </picture>
        </div>
        <div class = "pattern_content_2">
        <picture>
            <source srcset="http://works/wp-content/uploads/2022/03/760-uzor.png" media="(min-width:321px) and (max-width:760px)">
            <source srcset="http://works/wp-content/uploads/2022/03/320-uzor.png" media="(min-width:0px) and (max-width:320px)">

            <img srcset = "<?php the_field('pattern_content_2') ?>"/>

            </picture>
        </div>
        <div class = "pattern_content_3">
        <picture>
            <source srcset="http://works/wp-content/uploads/2022/03/760-uzor.png" media="(min-width:321px) and (max-width:760px)">
            <source srcset="http://works/wp-content/uploads/2022/03/320-uzor.png" media="(min-width:0px) and (max-width:320px)">

            <img srcset = "<?php the_field('pattern_content_3') ?>"/>

            </picture>
        </div>
        <div class = "mens_department"><?php the_field('mens_department') ?></div>
        
        
        <button class = "button_1" >
        <picture>
            <source srcset="http://works/wp-content/uploads/2022/03/760-button.png" media="(min-width:321px) and (max-width:760px)">
            <source srcset="http://works/wp-content/uploads/2022/03/320-button.png" media="(min-width:0px) and (max-width:320px)">

            <img srcset = "<?php the_field('button_1') ?>"/>

            </picture>
            <a class = "more_details_1"><?php the_field('more_details_1') ?></a>
        </button>
        

        <div class = "womens_department"><?php the_field('womens_department') ?></div>
        
        <button class = "button_2">
        <picture>
            <source srcset="http://works/wp-content/uploads/2022/03/760-button.png" media="(min-width:321px) and (max-width:760px)">
            <source srcset="http://works/wp-content/uploads/2022/03/320-button.png" media="(min-width:0px) and (max-width:320px)">

            <img srcset = "<?php the_field('button_2') ?>"/>

        </picture>
            <a class = "more_details_2"><?php the_field('more_details_2') ?></a>
        </button>
        <div class = "children_department"><?php the_field('children_department') ?></div>
       
        <button class = "button_3">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-button.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/320-button.png" media="(min-width:0px) and (max-width:320px)">

                <img srcset = "<?php the_field('button_3') ?>"/>

            </picture>
            <a class = "more_details_3"><?php the_field('more_details_3') ?></a>
        </button>

        <!-- Men s scroll -->
        <div class = "scroll-slider">
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_1') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_2') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_3') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_4') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_5') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_6') ?>" alt="">

            </picture>
            </div>
        </div>
        <!-- Women s scroll -->
        <div class = "scroll-slider_1">
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_7') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_8') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_9') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_10') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_11') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_1">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_12') ?>" alt="">

            </picture>
            </div>
        </div>
        <!-- Children s scroll -->
        <div class = "scroll-slider_2">
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_13') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_14') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_15') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_16') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_17') ?>" alt="">

            </picture>
            </div>
            <div class="moving_slayda_2">
            <picture>
                <source srcset="http://works/wp-content/uploads/2022/03/760-dress.png" media="(min-width:321px) and (max-width:760px)">
                <source srcset="http://works/wp-content/uploads/2022/03/slide_wom_1_.png" media="(min-width:0px) and (max-width:320px)">

                <img src="<?php the_field('moving_slayda_18') ?>" alt="">

            </picture>
            </div>
        </div>
